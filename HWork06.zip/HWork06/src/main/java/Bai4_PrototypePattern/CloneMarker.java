package Bai4_PrototypePattern;

public interface CloneMarker {
}
