package Bai4_PrototypePattern;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Shape> shapes = new ArrayList<>();
        shapes.add(new Circle("Red", 5));
        shapes.add(new Rectangle("Blue", 4, 6));

        System.out.println("----ORIGINAL SHAPES----");
        for (Shape s : shapes) {
            s.draw();
            System.out.println();
        }

        List<Shape> cloned = new ArrayList<>();
        for (Shape s : shapes) {
            cloned.add(s.clone());
        }

        System.out.println("----CLONED SHAPES----");
        for (Shape s : cloned) {
            s.draw();
            System.out.println(" Status: Cloned successfully!\n");
        }
    }
}

