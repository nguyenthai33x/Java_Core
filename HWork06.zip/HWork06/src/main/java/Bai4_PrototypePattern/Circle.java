package Bai4_PrototypePattern;

public class Circle extends Shape {
    private int radius;

    public Circle(String color, int radius) {
        super(color);
        this.radius = radius;
    }
    public int getRadius() {
        return radius;
    }

    @Override
    public void draw() {
        System.out.println("---Circle---");
        System.out.println("   ➤ Color: " + color);
        System.out.println("   ➤ Radius: " + radius);
    }

    @Override
    public Circle clone() {
        return (Circle) super.clone();
    }
}


