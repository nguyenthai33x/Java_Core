package Bai4_PrototypePattern;

public class Rectangle extends Shape {
    private int width;
    private int height;

    public Rectangle(String color, int width, int height) {
        super(color);
        this.width = width;
        this.height = height;
    }
    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    @Override
    public void draw() {
        System.out.println("---Rectangle---");
        System.out.println("   ➤ Color: " + color);
        System.out.println("   ➤ Width: " + width);
        System.out.println("   ➤ Height: " + height);
    }

    @Override
    public Rectangle clone() {
        return (Rectangle) super.clone(); // shallow clone đủ
    }
}

