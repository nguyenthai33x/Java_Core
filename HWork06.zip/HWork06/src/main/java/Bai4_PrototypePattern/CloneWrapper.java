package Bai4_PrototypePattern;

public class CloneWrapper extends Shape implements CloneMarker {
    private final Shape wrapped;

    public CloneWrapper(Shape wrapped) {
        super(wrapped.color);
        this.wrapped = wrapped;
    }

    @Override
    public void draw() {
        String type = "[Clone]";
        String status = "✅ Cloned successfully!";

        if (wrapped instanceof Circle) {
            Circle c = (Circle) wrapped;
            System.out.println("🌀 🟢 " + type + " 🟣 Circle 🎯");
            System.out.println("    ➤ Color: ❤️ " + c.color);
            System.out.println("    ➤ Radius: 🔵 " + c.getRadius());
            System.out.println("    ✅ Status: " + status);
        } else if (wrapped instanceof Rectangle) {
            Rectangle r = (Rectangle) wrapped;
            System.out.println("🟪 ⬜ " + type + " 🟥 Rectangle 📐");
            System.out.println("    ➤ Color: 💙 " + r.color);
            System.out.println("    ➤ Width:  📏 " + r.getWidth());
            System.out.println("    ➤ Height: 📏 " + r.getHeight());
            System.out.println("    ✅ Status: " + status);
        } else {
            System.out.println("Unknown shape type.");
        }
    }
}
