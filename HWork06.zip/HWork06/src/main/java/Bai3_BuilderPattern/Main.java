package Bai3_BuilderPattern;

public class Main {
    public static void main(String[] args) {
        UIContainer ui = UIBuilder.create()
                .addButton("OK")
                .addTextField("Username")
                .addLabel("Welcome")
                .addButton("Cancel")
                .build();

        ui.render();
    }
}

