package Bai3_BuilderPattern;

public class Label extends UIComponent {
    public Label(String content) {
        super(content);
    }

    @Override
    public void render() {
        System.out.println("Label: [" + content + "]");
    }
}