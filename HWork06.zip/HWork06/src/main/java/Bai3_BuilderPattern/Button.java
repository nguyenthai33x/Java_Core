package Bai3_BuilderPattern;

public class Button extends UIComponent {
    public Button(String content) {
        super(content);
    }

    @Override
    public void render() {
        System.out.println("Button: [" + content + "]");
    }
}

