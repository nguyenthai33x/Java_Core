package Bai3_BuilderPattern;

import java.util.List;

public class UIContainer {
    private List<UIComponent> components;

    public UIContainer(List<UIComponent> components) {
        this.components = components;
    }

    public void render() {
        System.out.println("---- UI Layout ----");
        for (UIComponent comp : components) {
            comp.render();
        }
        System.out.println("-------------------");
    }
}

