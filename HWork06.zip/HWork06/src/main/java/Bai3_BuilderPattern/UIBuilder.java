package Bai3_BuilderPattern;

import java.util.ArrayList;
import java.util.List;

public class UIBuilder {
    private List<UIComponent> components;

    private UIBuilder() {
        components = new ArrayList<>();
    }

    public static UIBuilder create() {
        return new UIBuilder();
    }

    public UIBuilder addButton(String text) {
        components.add(new Button(text));
        return this;
    }

    public UIBuilder addTextField(String placeholder) {
        components.add(new TextField(placeholder));
        return this;
    }

    public UIBuilder addLabel(String title) {
        components.add(new Label(title));
        return this;
    }

    public UIContainer build() {
        return new UIContainer(components);
    }
}

