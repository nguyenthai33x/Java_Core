package Bai3_BuilderPattern;

public abstract class UIComponent {
    protected String content;

    public UIComponent(String content) {
        this.content = content;
    }

    public abstract void render();

}


