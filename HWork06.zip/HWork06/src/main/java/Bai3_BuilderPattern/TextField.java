package Bai3_BuilderPattern;

public class TextField extends UIComponent {
    public TextField(String content) {
        super(content);
    }

    @Override
    public void render() {
        System.out.println("TextField: [" + content + "]");
    }
}

