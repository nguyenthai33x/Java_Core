package Bai2_BuilderPattern;

public class Computer {
    private final String CPU;
    private final int RAM;
    private final int storage;

    private final String graphicCard;
    private final boolean isBluetoothEnabled;
    private final boolean isWifiEnabled;

    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.graphicCard = builder.graphicCard;
        this.isBluetoothEnabled = builder.isBluetoothEnabled;
        this.isWifiEnabled = builder.isWifiEnabled;
    }

    public static Builder builder(String CPU, int RAM, int storage) {
        return new Builder(CPU, RAM, storage);
    }

    public static class Builder {
        private final String CPU;
        private final int RAM;
        private final int storage;

        private String graphicCard = "Integrated";
        private boolean isBluetoothEnabled = false;
        private boolean isWifiEnabled = false;

        public Builder(String CPU, int RAM, int storage) {
            this.CPU = CPU;
            this.RAM = RAM;
            this.storage = storage;
        }

        public Builder graphicCard(String graphicCard) {
            this.graphicCard = graphicCard;
            return this;
        }

        public Builder bluetoothEnabled(boolean enabled) {
            this.isBluetoothEnabled = enabled;
            return this;
        }

        public Builder wifiEnabled(boolean enabled) {
            this.isWifiEnabled = enabled;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }

    public String getCPU() { return CPU; }
    public int getRAM() { return RAM; }
    public int getStorage() { return storage; }
    public String getGraphicCard() { return graphicCard; }
    public boolean isBluetoothEnabled() { return isBluetoothEnabled; }
    public boolean isWifiEnabled() { return isWifiEnabled; }
}
