package Bai2_BuilderPattern;

public class Main {
    public static void main(String[] args) {
        Computer pc = Computer.builder("Intel i7", 16, 512)
                .graphicCard("NVIDIA RTX 3050")
                .bluetoothEnabled(true)
                .wifiEnabled(true)
                .build();

        System.out.println("CPU: " + pc.getCPU());
        System.out.println("RAM: " + pc.getRAM() + " GB");
        System.out.println("Storage: " + pc.getStorage() + " GB");
        System.out.println("Graphic Card: " + pc.getGraphicCard());
        System.out.println("Bluetooth: " + pc.isBluetoothEnabled());
        System.out.println("WiFi: " + pc.isWifiEnabled());
    }
}

