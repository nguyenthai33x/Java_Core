package Bai5_PrototypePattern;

public class Main {
    public static void main(String[] args) {
        Document doc1 = new Document("Java Design Patterns", "Tài liệu về các mẫu thiết kế trong Java.");
        Section s1 = new Section("Introduction", "Giới thiệu về Design Patterns.");
        s1.addImage(new Image("intro1.png", "Diagram 1"));
        s1.addImage(new Image("intro2.png", "Diagram 2"));

        Section s2 = new Section("Prototype Pattern", "Giải thích về Prototype Pattern.");
        s2.addImage(new Image("prototype.png", "Prototype Diagram"));

        doc1.addSection(s1);
        doc1.addSection(s2);

        Document doc2 = doc1.clone();

        doc2.getSections().get(0).addImage(new Image("extra.png", "Extra Image"));
        doc2.getSections().get(1).setText("Nội dung sửa đổi cho Prototype Pattern.");

        System.out.println("----- Original Document -----");
        System.out.println(doc1);

        System.out.println("\n----- Cloned Document -----");
        System.out.println(doc2);
    }
}