package Bai5_PrototypePattern;

import java.util.ArrayList;
import java.util.List;

// Lớp Image
class Image implements Cloneable {
    private String url;
    private String description;

    public Image(String url, String description) {
        this.url = url;
        this.description = description;
    }

    public String getUrl() {
        return url;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public Image clone() {
        try {
            return (Image) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
    public String toString() {
        return "Image{url='" + url + "', description='" + description + "'}";
    }
}

// Lớp Section
class Section implements Cloneable {
    private String title;
    private String text;
    private List<Image> images;

    public Section(String title, String text) {
        this.title = title;
        this.text = text;
        this.images = new ArrayList<>();
    }

    // Getter cho text
    public String getText() {
        return text;
    }

    // Setter cho text
    public void setText(String text) {
        this.text = text;
    }

    // Các getter/setter khác nếu cần
    public String getTitle() {
        return title;
    }

    public List<Image> getImages() {
        return images;
    }

    public void addImage(Image img) {
        images.add(img);
    }

    @Override
    public Section clone() {
        try {
            Section cloned = (Section) super.clone();
            cloned.images = new ArrayList<>();
            for (Image img : this.images) {
                cloned.images.add(img.clone());
            }
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
    public String toString() {
        return "Section{title='" + title + "', text='" + text + "', images=" + images + "}";
    }
}


// Lớp Document
class Document implements Cloneable {
    private String title;
    private String content;
    private List<Section> sections;

    public Document(String title, String content) {
        this.title = title;
        this.content = content;
        this.sections = new ArrayList<>();
    }

    public void addSection(Section section) {
        sections.add(section);
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public List<Section> getSections() {
        return sections;
    }

    @Override
    public Document clone() {
        try {
            Document cloned = (Document) super.clone();
            // Deep copy List<Section>
            cloned.sections = new ArrayList<>();
            for (Section sec : this.sections) {
                cloned.sections.add(sec.clone());
            }
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }

    @Override
    public String toString() {
        return "Document{title='" + title + "', content='" + content + "', sections=" + sections + "}";
    }
}



