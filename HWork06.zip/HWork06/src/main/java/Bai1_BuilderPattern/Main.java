package Bai1_BuilderPattern;

public class Main {
    public static void main(String[] args) {
        User user = User.builder()
                .username("thai123")
                .email("thai@gmail.com")
                .age(22)
                .phone("0901234567")
                .build();

        System.out.println("Username: " + user.getUsername());
        System.out.println("Email: " + user.getEmail());
        System.out.println("Age: " + user.getAge());
        System.out.println("Phone: " + user.getPhone());
    }
}
