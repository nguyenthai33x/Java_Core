package Bai2_ThreadSafe_Singleton;

public class Main {
    public static void main(String[] args) {
        Runnable logTask = () -> {
            Logger logger = Logger.getInstance();
            logger.log("Đây là thông điệp nhật ký từ thread: " + Thread.currentThread().getName());
        };

        Thread thread1 = new Thread(logTask, "1");
        Thread thread2 = new Thread(logTask, "2");
        Thread thread3 = new Thread(logTask, "3");
        Thread thread4 = new Thread(logTask, "4");

        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();

        try {
            thread1.join();
            thread2.join();
            thread3.join();
            thread4.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
