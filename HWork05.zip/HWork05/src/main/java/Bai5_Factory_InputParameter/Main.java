package Bai5_Factory_InputParameter;

public class Main {
    public static void main(String[] args) {
        Notification notification1 = NotificationFactory.getNotification("email");
        if (notification1 != null) {
            notification1.send();
        }

        Notification notification2 = NotificationFactory.getNotification("sms");
        if (notification2 != null) {
            notification2.send();
        }

        Notification notification3 = NotificationFactory.getNotification("push");
        if (notification3 != null) {
            notification3.send();
        }

        Notification notificationInvalid = NotificationFactory.getNotification("fax");
        if (notificationInvalid == null) {
            System.out.println("Loại thông báo không hợp lệ.");
        }
    }
}

