package Bai5_Factory_InputParameter;

public class PushNotification implements Notification {
    @Override
    public void send() {
        System.out.println("Gửi thông báo qua Push Notification.");
    }
}