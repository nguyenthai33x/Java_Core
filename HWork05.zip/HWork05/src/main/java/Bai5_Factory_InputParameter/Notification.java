package Bai5_Factory_InputParameter;

public interface Notification {
    void send();
}

