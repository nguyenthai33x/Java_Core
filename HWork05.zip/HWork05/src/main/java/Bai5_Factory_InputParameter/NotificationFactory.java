package Bai5_Factory_InputParameter;

public class NotificationFactory {
    public static Notification getNotification(String notificationType) {
        if (notificationType == null) {
            return null;
        }
        if (notificationType.equalsIgnoreCase("email")) {
            return new EmailNotification();
        } else if (notificationType.equalsIgnoreCase("sms")) {
            return new SMSNotification();
        } else if (notificationType.equalsIgnoreCase("push")) {
            return new PushNotification();
        }
        return null;
    }
}

