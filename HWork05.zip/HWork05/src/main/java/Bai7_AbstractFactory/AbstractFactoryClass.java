package Bai7_AbstractFactory;

// Interface Button
interface Button {
    void paint();
}

// Interface Checkbox
interface Checkbox {
    void paint();
}

// Interface Menu
interface Menu {
    void paint();
}

// Interface Scrollbar
interface Scrollbar {
    void paint();
}

// Windows implementations
class WindowsButton implements Button {
    public void paint() {
        System.out.println("Vẽ nút bấm kiểu Windows.");
    }
}

class WindowsCheckbox implements Checkbox {
    public void paint() {
        System.out.println("Vẽ checkbox kiểu Windows.");
    }
}

class WindowsMenu implements Menu {
    public void paint() {
        System.out.println("Vẽ menu kiểu Windows.");
    }
}

class WindowsScrollbar implements Scrollbar {
    public void paint() {
        System.out.println("Vẽ scrollbar kiểu Windows.");
    }
}

// Mac implementations
class MacButton implements Button {
    public void paint() {
        System.out.println("Vẽ nút bấm kiểu Mac.");
    }
}

class MacCheckbox implements Checkbox {
    public void paint() {
        System.out.println("Vẽ checkbox kiểu Mac.");
    }
}

class MacMenu implements Menu {
    public void paint() {
        System.out.println("Vẽ menu kiểu Mac.");
    }
}

class MacScrollbar implements Scrollbar {
    public void paint() {
        System.out.println("Vẽ scrollbar kiểu Mac.");
    }
}

interface GUIFactory {
    Button createButton();
    Checkbox createCheckbox();
    Menu createMenu();
    Scrollbar createScrollbar();
}

class WindowsFactory implements GUIFactory {
    public Button createButton() {
        return new WindowsButton();
    }
    public Checkbox createCheckbox() {
        return new WindowsCheckbox();
    }
    public Menu createMenu() {
        return new WindowsMenu();
    }
    public Scrollbar createScrollbar() {
        return new WindowsScrollbar();
    }
}

class MacFactory implements GUIFactory {
    public Button createButton() {
        return new MacButton();
    }
    public Checkbox createCheckbox() {
        return new MacCheckbox();
    }
    public Menu createMenu() {
        return new MacMenu();
    }
    public Scrollbar createScrollbar() {
        return new MacScrollbar();
    }
}

class Application {
    private Button button;
    private Checkbox checkbox;
    private Menu menu;
    private Scrollbar scrollbar;

    public Application(GUIFactory factory) {
        button = factory.createButton();
        checkbox = factory.createCheckbox();
        menu = factory.createMenu();
        scrollbar = factory.createScrollbar();
    }

    public void paint() {
        button.paint();
        checkbox.paint();
        menu.paint();
        scrollbar.paint();
    }
}

public class AbstractFactoryClass {
    private static Application configureApplication(String os) {
        GUIFactory factory;
        if (os.equalsIgnoreCase("Windows")) {
            factory = new WindowsFactory();
        } else if (os.equalsIgnoreCase("Mac")) {
            factory = new MacFactory();
        } else {
            throw new IllegalArgumentException("Unsupported OS.");
        }
        return new Application(factory);
    }

    public static void main(String[] args) {
        System.out.println("=== Windows UI ===");
        Application windowsApp = configureApplication("Windows");
        windowsApp.paint();

        System.out.println();

        System.out.println("=== Mac UI ===");
        Application macApp = configureApplication("Mac");
        macApp.paint();
    }
}

