package Bai6_FactoryPattern;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

interface Product {
    void use();
}

class ProductA implements Product {
    @Override
    public void use() {
        System.out.println("Using Product A");
    }
}

class ProductB implements Product {
    @Override
    public void use() {
        System.out.println("Using Product B");
    }
}

class ProductFactory {
    private static final Map<String, Supplier<Product>> registry = new HashMap<>();

    public static void register(String type, Supplier<Product> supplier) {
        registry.put(type.toLowerCase(), supplier);
    }

    public static Product create(String type) {
        Supplier<Product> supplier = registry.get(type.toLowerCase());
        if (supplier != null) {
            return supplier.get();
        }
        throw new IllegalArgumentException("No product registered with type: " + type);
    }
}

public class DFactory {
    public static void main(String[] args) {
        // Đăng ký các product
        ProductFactory.register("productA", ProductA::new);
        ProductFactory.register("productB", ProductB::new);

        Product product1 = ProductFactory.create("productA");
        product1.use();

        Product product2 = ProductFactory.create("productB");
        product2.use();

        try {
            ProductFactory.create("productC");
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}


