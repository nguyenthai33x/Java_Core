package Bai1_Singleton;

public class Main {
    public static void main(String[] args) {
        AppConfig config = AppConfig.getInstance();

        config.displayConfig();
    }
}
