package Bai1_Singleton;

public class AppConfig {
    private static AppConfig instance;
    private AppConfig() {
        System.out.println("AppConfig instance is created.");
    }
    public static AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }
    public void displayConfig() {
        System.out.println("Đây là cấu hình ứng dụng.");
    }
}
