package Bai3_EnumSingleton;

public class EnumSingleton {
    public enum DatabaseConnection {
        INSTANCE;

        private boolean connected;

        DatabaseConnection() {
            connected = false;
        }
        public void _connect() {
            if (!connected) {
                System.out.println("Đang kết nối tới cơ sở dữ liệu...");
                connected = true;
                System.out.println("Kết nối thành công!");
            } else {
                System.out.println("Đã kết nối rồi, không kết nối lại.");
            }
        }

        public boolean isConnected() {
            return connected;
        }
    }

    public static void main(String[] args) {
        DatabaseConnection connection1 = DatabaseConnection.INSTANCE;
        connection1._connect();

        DatabaseConnection connection2 = DatabaseConnection.INSTANCE;
        connection2._connect();

        System.out.println("connection1 và connection2 có phải cùng instance không? " + (connection1 == connection2));
    }
}
