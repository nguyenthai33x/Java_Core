package Bai4_Factory;

public interface Shape {
    void draw();
}

