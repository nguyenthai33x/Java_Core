package Bai4_Factory;

public class Circle implements Shape {
    @Override
    public void draw() {
        System.out.println("Vẽ hình tròn.");
    }
}

